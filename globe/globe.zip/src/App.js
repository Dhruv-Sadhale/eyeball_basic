import logo from './logo.svg';
// import './App.css';
import Indexglobe from './components/indexglobe/IndexGlobe'

function App() {
  return (
    <div className="App">
      <Indexglobe />
    </div>
  );
}

export default App;
